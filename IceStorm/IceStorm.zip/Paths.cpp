#include "Paths.h"
string Paths::levelPath = "./level.txt";
string Paths::texturesListPath = "./Textures/texturesList.txt";

Paths::Paths()
{
}
