#include "C_Rect.h"

C_Rect::C_Rect()
	:x(0), y(0), w(0), h(0), px(0), py(0), mx(0), my(0)
{
}


C_Rect::~C_Rect()
{
}
