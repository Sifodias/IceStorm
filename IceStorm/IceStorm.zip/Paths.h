#pragma once
#include <string>
using namespace std;

class Paths {
public :
	Paths();
	static string levelPath;
	static string texturesListPath;
};