#include "Useful_Fonctions.h"
#include "Renderer.h"
#include "Map.h"
#include "Textures_Manager.h"

void initialize_game()
{
	Renderer::initAll();
	Map::loadLevel();
	Textures_Manager::TMInit();
}

void main_event_loop()
{
	SDL_Event e;
	int out = 0;
	while (out == 0)
	{
		if (SDL_PollEvent(&e) != 0)
		{
			if (e.type == SDL_QUIT)
			{
				out = 1;
				Renderer::quitAll();
			}
		}
	}
}

std::ifstream loadFromTxt(std::string path)
{
	std::ifstream level_stream;
	level_stream.open(path.c_str());
	if (!level_stream)
	{
		std::cout << "Can't load the stream";
	}
	return level_stream;
}