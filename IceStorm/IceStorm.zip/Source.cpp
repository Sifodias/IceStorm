//TODO :
//Finish textures engine
//Physics engine
//Dialogues engine
//GH engine

#include "Useful_Fonctions.h"

int main(int argc, char* argv[])
{
	initialize_game();

	main_event_loop();

	//system("pause");
	return 0;
}