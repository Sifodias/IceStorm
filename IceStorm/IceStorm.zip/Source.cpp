#include "Useful_Fonctions.h"

int main(int argc, char* argv[])
{
	initialize_game();
	
	main_event_loop();

	return 0;
}