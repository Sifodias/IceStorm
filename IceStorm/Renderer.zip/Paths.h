//this class contains the paths used in the engine
#pragma once
#include <string>
using namespace std;

class Paths {
public :
	static string levelPath;
	static string texturesListPath;
	static string asciiPath;
	static string entData;
};