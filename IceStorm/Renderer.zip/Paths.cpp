#include "Paths.h"

string Paths::levelPath = "./Levels/level.txt";
string Paths::texturesListPath = "./Textures/texturesList.txt";
string Paths::asciiPath = "./Polices/asciiList.txt";
string Paths::entData = "./Entities/ent_data.txt";