//TODO :
//mettre des securit�s sur les vectors
#include "Engine_Manager.h"

int main(int argc, char* argv[])
{
	Init_game();

	main_event_loop();

	return 0;
}

