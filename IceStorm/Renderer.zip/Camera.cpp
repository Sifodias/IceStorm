#include "Camera.h"

SDL_Rect Camera::innerRect;
SDL_Rect Camera::outerRect;