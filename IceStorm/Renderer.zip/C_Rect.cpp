//wall2.png
//wall2left.png
//wall2right.png
//wall2down.png
//wall1.png
//bite.jpg
//pannel.png